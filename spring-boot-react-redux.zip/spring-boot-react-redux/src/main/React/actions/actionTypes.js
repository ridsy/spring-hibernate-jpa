export const PRODUCTS_SAVED = 'PRODUCTS_SAVED'
export const PRODUCTS_ALL = 'PRODUCTS_ALL'
export const AJAX_BEGIN = 'AJAX_BEGIN'
export const AJAX_END = 'AJAX_END'