import request from 'axios';
import { browserHistory } from 'react-router'


function someAtion(){
    return {
        type: 'SOME_ACTION'
    }
}
