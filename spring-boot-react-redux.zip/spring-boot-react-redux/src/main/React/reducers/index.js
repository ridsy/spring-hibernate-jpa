export { default as main } from './MainReducer'
export { default as product } from './productReducer'
