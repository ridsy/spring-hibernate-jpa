/**
 * @startuml
 * class Employee{
 * -id:int
 * +{static} course
 * +get()
 * ~put()
 * #set()
 * }
 * note top of Employee : Employee is a general class
 * 
 * Employee "*" -- "1" Department :works in >
 * Employee o- Address
 * Person "1" *- "n" Address
 * Company -- Employee
 *@enduml
 */

