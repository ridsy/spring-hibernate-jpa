class Trainee
{
	int id;
	int score;
	String rating;
	Assessment as;
public Trainee(int id) {
		super();
		this.id = id;
	}

public int getId() {
	return id;
}

void takeAssessment(Assessment as,int score)
{
	this.as=as;
}
public Assessment getAs() {
	return as;
}
public int getScore() {
	return score;
}
public void setScore(int score) {
	this.score = score;
}
public String getRating() {
	return rating;
}
public void setRating(String rating) {
	this.rating = rating;
}
}
abstract class Assessment
{
	int weightage;
	
	public int getWeightage() {
		return weightage;
	}
	abstract void setWeightage(int weightage);
}
class OnlineAssessment extends Assessment
{
	@Override
	void setWeightage(int weightage) {
		// TODO Auto-generated method stub
		this.weightage=weightage;
	}
}
class CodingAssessment extends Assessment
{
	@Override
	void setWeightage(int weightage) {
		// TODO Auto-generated method stub
		this.weightage=weightage;
	}
}
class ClassPerformance extends Assessment
{
	@Override
	void setWeightage(int weightage) {
		// TODO Auto-generated method stub
		this.weightage=weightage;
	}	
}
class ScoreCalculator
{
	enum Rating
	{
		Excellent, VeryGood, Good, Average;
	}
	
	int calculateScore(Trainee t)
	{
		int finalscore=0;
		//Calculate Final score---t.getAssessment().getWeightage()
		t.setScore(finalscore);
		return finalscore;
	}
	void assignRating(Trainee t)
	{
	t.setRating((t.getScore()>85? ""+Rating.Excellent:(t.getScore()>70?""+Rating.VeryGood:(t.getScore()>60?""+Rating.Good : ""+Rating.Average))));
	}
}
public class OnlineAssessmentDemo {
	
	public static void main(String []args)
	{
		Assessment as1=new OnlineAssessment();
		Assessment as2=new CodingAssessment();
		Assessment as3=new ClassPerformance();
		
		Trainee t1=new Trainee(101);
		
		ScoreCalculator sc=new ScoreCalculator();
		
		as1.setWeightage(25);
		t1.takeAssessment(as1);
		sc.calculateScore(t1);
		
		as2.setWeightage(40);
		t1.takeAssessment(as2);
		sc.calculateScore(t1);
		
		as3.setWeightage(15);
		t1.takeAssessment(as3);
		sc.calculateScore(t1);
		
		sc.assignRating(t1);
		
		System.out.println("Id : "+t1.getId());
		System.out.println("Score : "+t1.getScore());
		System.out.println("Rating : "+t1.getRating());
		
	}
}
