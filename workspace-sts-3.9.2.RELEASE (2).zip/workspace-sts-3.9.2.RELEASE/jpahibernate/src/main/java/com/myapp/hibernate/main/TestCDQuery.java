package com.myapp.hibernate.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.myapp.hibernate.model.CD;
import com.myapp.hibernate.model.Flight;
import com.myapp.hibernate.model.Musician;

public class TestCDQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAHIBERNATE");
		EntityManager em = emf.createEntityManager();

		
		CD cd=em.find(CD.class, 2L);
		System.out.println(cd);
		cd.getMusicians().forEach(System.out::println);
		// Detach state
		em.close();
		emf.close();
	}

}
