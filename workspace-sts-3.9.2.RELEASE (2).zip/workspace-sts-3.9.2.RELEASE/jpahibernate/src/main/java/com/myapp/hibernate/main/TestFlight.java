package com.myapp.hibernate.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.myapp.hibernate.model.CD;
import com.myapp.hibernate.model.Flight;
import com.myapp.hibernate.model.Musician;

public class TestFlight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAHIBERNATE");
		EntityManager em = emf.createEntityManager();

		// Transient state
		CD cd1=new CD("PADMAVATH","Classical",175,"Classical",3.5);
		Musician musician1=new Musician("Michael","Jackson","Guitar");
		musician1.setCd(cd1);
		cd1.getMusicians().add(musician1);
		Musician musician2=new Musician("AR","rahman","Tabla");
		musician2.setCd(cd1);
		cd1.getMusicians().add(musician2);
//		cd1.getMusicians().add(musician1);
//		cd1.getMusicians().add(musician2);
//		Flight flight = new Flight("Una", "Gurgaon");
		
		// Persistence state

		EntityTransaction trxn = em.getTransaction();
		try {
			trxn.begin();
			em.persist(cd1);
			trxn.commit();
		} catch (Exception e) {
			trxn.rollback();
			e.printStackTrace();
		}
		// Detach state
		em.close();
		emf.close();
	}

}
