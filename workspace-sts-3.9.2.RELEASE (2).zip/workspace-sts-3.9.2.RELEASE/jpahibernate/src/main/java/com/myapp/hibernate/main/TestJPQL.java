package com.myapp.hibernate.main;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.myapp.hibernate.model.Benefit;
import com.myapp.hibernate.model.CD;
import com.myapp.hibernate.model.Employee;
import com.myapp.hibernate.model.Flight;
import com.myapp.hibernate.model.Musician;
import com.myapp.hibernate.model.Order;

public class TestJPQL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAHIBERNATE");
		EntityManager em = emf.createEntityManager();

//	      Query query = em.createNamedQuery("OrderFindByStatus");  
//	      query.setParameter("STATUS","NEW");
//	      query.getResultList().forEach(System.out::println);
	     
	      
	     
	      TypedQuery<Order> query1 = em.createNamedQuery("OrderFindByStatus",Order.class);  
	      query1.setParameter("STATUS","NEW");
	      query1.getResultList().forEach(System.out::println);
	      
	      TypedQuery<Order> query2 = em.createNamedQuery("OrderFindByOrderPlacedDate",Order.class);
	      query2.setParameter("TIMEPLACED",new Date());
	      query2.getResultList().forEach(System.out::println);
	      
	      
	      TypedQuery<Order> query3 = em.createNamedQuery("OrderFindByOrder",Order.class);  
	      query3.setParameter(0,"NEW");
	      query3.getResultList().forEach(System.out::println);
	     
	      //Step1:
	       CriteriaBuilder cb = em.getCriteriaBuilder();
	      CriteriaQuery cq= cb.createQuery();
	      Root<Order> root=cq.from(Order.class);
	      Predicate pcStatus=cb.equal(root.get("status"),"NEW");
	      cq.where(pcStatus);
	      cq.select(root);
	      
	      em.createQuery(cq).getResultList().forEach(System.out::println);
	      
	      
		
		// Persistence state

		// Detach state
		em.close();
		emf.close();
	}

}
