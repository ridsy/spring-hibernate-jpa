package com.myapp.hibernate.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="OTM_CD")
public class CD {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	private String title;
	
	private String description;
	
	private double cost;
	
	private String genre;
	
	private double totalDuration;

	@OneToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL,mappedBy="cd")//
	//@JoinColumn(name="CD_Id")//CD is the owner
	private Set<Musician> musicians=new HashSet<Musician>();
	
	
	public String getGenre() {
		return genre;
	}


	public void setGenre(String genre) {
		this.genre = genre;
	}


	public Set<Musician> getMusicians() {
		return musicians;
	}


	public void setMusicians(Set<Musician> musicians) {
		this.musicians = musicians;
	}

	
	

	public CD() {
		// TODO Auto-generated constructor stub
	}
	
	
	public CD(String title, String description, double cost,String genre, double totalDuration) {
		this.title = title;
		this.description = description;
		this.cost = cost;
		this.genre=genre;
		this.totalDuration = totalDuration;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CD other = (CD) obj;
		if (id != other.id)
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}


	public double getTotalDuration() {
		return totalDuration;
	}

	public void setTotalDuration(double totalDuration) {
		this.totalDuration = totalDuration;
	}

	public long getId() {
		return id;
	}

	private void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CD [id=");
		builder.append(id);
		builder.append(", title=");
		builder.append(title);
		builder.append(", description=");
		builder.append(description);
		builder.append(", cost=");
		builder.append(cost);
		builder.append(", totalDuration=");
		builder.append(totalDuration);
		builder.append("]");
		return builder.toString();
	}
	
}
