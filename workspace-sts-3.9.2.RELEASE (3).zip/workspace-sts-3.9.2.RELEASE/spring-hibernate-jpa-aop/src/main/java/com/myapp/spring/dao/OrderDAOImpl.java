package com.myapp.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.myapp.spring.hibernate.model.Order;

@Repository  //To specify that data is managed here
public class OrderDAOImpl implements OrderDAO {
	
	@PersistenceContext //To get entity manager from local container entity manager factory bean
	private EntityManager em;
	
	@Autowired
	private PlatformTransactionManager transactionManager;

	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(propagation=Propagation.SUPPORTS,isolation=Isolation.READ_COMMITTED,rollbackFor=HibernateException.class)
	public List<Order> findAll() {
		
		return em.createNamedQuery("OrderFindAll").getResultList();
	}


	@Override
	//@Transactional(propagation=Propagation.REQUIRED,isolation=Isolation.READ_COMMITTED)//method has to run within a transaction
	public void save(Order order) {
		
		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
	     def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		
		TransactionStatus status = transactionManager.getTransaction(def);

		try {
		em.persist(order);
		}
		catch(Exception ex) {
			transactionManager.rollback(status);
			throw ex;
		}
		transactionManager.commit(status);
	}

}
