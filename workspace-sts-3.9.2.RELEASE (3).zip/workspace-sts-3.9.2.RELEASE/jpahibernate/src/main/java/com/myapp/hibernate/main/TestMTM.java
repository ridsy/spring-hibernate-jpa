package com.myapp.hibernate.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.myapp.hibernate.model.Benefit;
import com.myapp.hibernate.model.CD;
import com.myapp.hibernate.model.Employee;
import com.myapp.hibernate.model.Flight;
import com.myapp.hibernate.model.Musician;

public class TestMTM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAHIBERNATE");
		EntityManager em = emf.createEntityManager();

		// Transient state
		//Employee employee = new Employee("","efgh","abcdecom");
		Employee employee1 = new Employee("Virat", "Kohli", "virat@kohli.com");
		Employee employee2 = new Employee("Ridhi", "Garg", "rg@gmail.com");
		Benefit b1 =  new Benefit("MEDICAL",89990);
		Benefit b2 = new Benefit("DENTAL",99990);
		
		
//		employee1.getBenefits().put("MEDICAL", new Benefit("MEDICAL",89990));		
//		employee1.getBenefits().put("DENTAL", new Benefit("DENTAL",99990));
//		employee2.getBenefits().put("MEDICAL", new Benefit("MEDICAL",89990));
//		employee2.getBenefits().put("DENTAL", new Benefit("DENTAL",99990));
		
		employee1.getBenefits().put("MEDICAL",b1);		
		employee1.getBenefits().put("DENTAL", b2);
		employee2.getBenefits().put("MEDICAL",b1);
		employee2.getBenefits().put("DENTAL", b2);
		
		
		

//	        Employee emp = em.find(Employee.class, 1L);
//	       //System.out.println(  emp.getBenefits().get("MEDICAL")); 
//	       
//	       emp.getBenefits().values().forEach(System.out::println);
		
		
		//em.find(Benefit.class, 14L).getEmployees().values().forEach(System.out::println);
	     
		
		
		// Persistence state
		EntityTransaction trxn = em.getTransaction();
		try {
			trxn.begin();
			em.persist(employee1);
			em.persist(employee2);
			trxn.commit();
		} catch (Exception e) {
			trxn.rollback();
			e.printStackTrace();
		}

		// Detach state
		em.close();
		emf.close();
	}

}
