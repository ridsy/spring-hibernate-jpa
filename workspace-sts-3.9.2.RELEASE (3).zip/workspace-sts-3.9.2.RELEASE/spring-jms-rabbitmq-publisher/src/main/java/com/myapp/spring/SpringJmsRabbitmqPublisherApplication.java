package com.myapp.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJmsRabbitmqPublisherApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJmsRabbitmqPublisherApplication.class, args);
	}
}
