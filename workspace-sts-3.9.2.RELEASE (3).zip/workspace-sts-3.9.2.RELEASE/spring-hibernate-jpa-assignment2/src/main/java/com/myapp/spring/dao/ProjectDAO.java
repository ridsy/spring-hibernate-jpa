package com.myapp.spring.dao;

import java.util.List;

import com.myapp.spring.hibernate.model.Project;

public interface ProjectDAO {
	
	List<Project> findAll();
	
	void save(Project project);


}
