package com.myapp.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.myapp.spring.hibernate.model.Employee1;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	@PersistenceContext //To get entity manager from local container entity manager factory bean
	private EntityManager em;

	
	@Override
	public List<Employee1> findAll() {
		// TODO Auto-generated method stub
		return em.createQuery("from Employee1").getResultList();
	}

	@Override
	@Transactional
	public void save(Employee1 employee) {
		// TODO Auto-generated method stub
		em.persist(employee);

	}

	@Override
	@Transactional
	public Employee1 findByName(String fname) {
		// TODO Auto-generated method stub
		 TypedQuery<Employee1> query1 = em.createNamedQuery("EmployeeFindByName",Employee1.class);  
	      query1.setParameter("NAME",fname);
	    return  query1.getSingleResult();
	}

	@Override
	public List<Employee1> findByProject(String name) {
		TypedQuery<Employee1> query1 = em.createNamedQuery("EmployeeFindByProject", Employee1.class);
		query1.setParameter("NAME", name);
		return query1.getResultList();
	}

	@Override
	public List<Employee1> findBySkill(String name) {
		TypedQuery<Employee1> query1 = em.createNamedQuery("EmployeeFindBySkill", Employee1.class);
		query1.setParameter("NAME", name);
		return query1.getResultList();
	}

}
