package com.myapp.spring;



import java.util.Date;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.myapp.spring.config.AppConfig;
import com.myapp.spring.dao.EmployeeDAO;
import com.myapp.spring.dao.ProjectDAO;
import com.myapp.spring.hibernate.model.Employee1;
import com.myapp.spring.hibernate.model.Project;
import com.myapp.spring.hibernate.model.Skill;


public class TestSpringJpaHibernate {

	public static void main(String[] args) {

		//STEP 1: START THE SPRING CONTAINER
		
		AbstractApplicationContext springContainer = new AnnotationConfigApplicationContext(AppConfig.class);
		
		//STEP 2:Request For a bean inside the Spring container
		
		ProjectDAO projectDao = springContainer.getBean(ProjectDAO.class);
		EmployeeDAO employeeDao = springContainer.getBean(EmployeeDAO.class);
//		
//		Employee1 employee1 = new Employee1("Disha", "Singh", "sg@gmail.com");
//		//Employee1 employee2 = new Employee1("Rohit", "Sharma", "rs@gmail.com");
//		
//		Skill skill1 = new Skill("Java", "TECH");
//		Skill skill2 = new Skill("Fluency", "SOFT");
//		
//		employee1.getSkills().put("TECKKEY",skill1);		
//		employee1.getSkills().put("SOFTKEY", skill2);
////		employee2.getSkills().put("TECKKEY",skill1);
////		employee2.getSkills().put("SOFTKEY", skill2);
//		
//		//employeeDao.save(employee1);
//		//employeeDao.save(employee2);
//		
//		
//		Project project1 = new Project("SPRING", new Date());
//		
//		employee1.addProjectToEmployee(project1);
//		//employee2.addProjectToEmployee(project1);
//		
//		project1.getEmployees().add(employee1);
//		//project1.getEmployees().add(employee2);
//		
//		projectDao.save(project1);
		
		Employee1 e=employeeDao.findByName("Ridhi");
		System.out.println(e);
		
		employeeDao.findByProject("SPRING").forEach(System.out::println);
		employeeDao.findBySkill("Java").forEach(System.out::println);
//		
	
		//STEP 3:Close The Container
		springContainer.close();
	}

}
