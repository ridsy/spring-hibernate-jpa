package com.myapp.spring.hibernate.model;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@NamedQueries({
	@NamedQuery(name="EmployeeFindByName", query="select e from Employee1 as e where e.fName=:NAME"),
	@NamedQuery(name="EmployeeFindByProject", query="select e from Project p JOIN p.employees e where p.name = :NAME"),
	@NamedQuery(name="EmployeeFindBySkill", query="select e from Skill s JOIN s.employees e where s.name = :NAME") 
})


@Entity
public class Employee1 {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="EMPLOYEE_ID")
	private long id;
	
	@NotEmpty
	@Column(name="FIRST_NAME")
	private String fName;
	 
	@NotEmpty
	@Column(name="LAST_NAME")
	private String lName;
	
	@Email
	@Column(name="EMAIL" ,unique=true)
	private String email;
	
	@ManyToOne(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinColumn(name="PROJECT_ID",nullable=false,insertable=true,updatable=false)
	private Project project;
	
	@ManyToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinTable(name="EMPLOYEE_SKILLS",joinColumns=@JoinColumn(name="EMPLOYEE_ID"),inverseJoinColumns=
	@JoinColumn(name="SKILL_ID"))
	private Map<String,Skill> skills = new HashMap<>();
	
	public Employee1() {
		// TODO Auto-generated constructor stub
	}

	public Employee1(String fName, String lName, String email) {
		super();
		this.fName = fName;
		this.lName = lName;
		this.email = email;
	}

	public long getId() {
		return id;
	}

	private void setId(long id) {
		this.id = id;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Map<String, Skill> getSkills() {
		return skills;
	}

	public void setSkills(Map<String, Skill> skills) {
		this.skills = skills;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Employee1))
			return false;
		Employee1 other = (Employee1) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Employee1 [id=");
		builder.append(id);
		builder.append(", fName=");
		builder.append(fName);
		builder.append(", lName=");
		builder.append(lName);
		builder.append(", email=");
		builder.append(email);
		builder.append(", skills=");
		builder.append(skills);
		builder.append("]");
		return builder.toString();
	}
	
	public void addProjectToEmployee(Project project) {
		if(project == null) {
			return;
		}
		this.project=project;
		project.getEmployees().add(this);
	}
	
	

}
