package com.myapp.spring.dao;

import java.util.List;

import com.myapp.spring.hibernate.model.Skill;

public interface SkillDAO {
	
	List<Skill> findAll();
	
	void save(Skill skill);


}
