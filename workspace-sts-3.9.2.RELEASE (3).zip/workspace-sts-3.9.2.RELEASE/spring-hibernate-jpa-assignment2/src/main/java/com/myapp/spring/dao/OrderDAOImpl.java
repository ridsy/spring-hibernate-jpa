package com.myapp.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.myapp.spring.hibernate.model.Order;

@Repository  //To specify that data is managed here
public class OrderDAOImpl implements OrderDAO {
	
	@PersistenceContext //To get entity manager from local container entity manager factory bean
	private EntityManager em;

	
	@Override
	public List<Order> findAll() {
		
		return em.createQuery("from Order").getResultList();
	}


	@Override
	@Transactional
	public void save(Order order) {

		em.persist(order);
	}

}
