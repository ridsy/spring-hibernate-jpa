package com.myapp.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.myapp.spring.hibernate.model.Skill;

@Repository
public class SkillDAOImpl implements SkillDAO {
	
	@PersistenceContext //To get entity manager from local container entity manager factory bean
	private EntityManager em;


	@Override
	public List<Skill> findAll() {
		// TODO Auto-generated method stub
		return em.createQuery("from Skill").getResultList();
	}

	@Override
	@Transactional
	public void save(Skill skill) {
		// TODO Auto-generated method stub
		em.persist(skill);

	}

}
