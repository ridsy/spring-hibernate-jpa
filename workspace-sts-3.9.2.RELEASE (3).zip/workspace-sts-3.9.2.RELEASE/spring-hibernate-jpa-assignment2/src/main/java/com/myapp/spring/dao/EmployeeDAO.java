package com.myapp.spring.dao;

import java.util.List;

import com.myapp.spring.hibernate.model.Employee1;

public interface EmployeeDAO {
	
	List<Employee1> findAll();
	
	void save(Employee1 employee);
	
	Employee1 findByName(String fname);
	
	List<Employee1> findByProject(String name);
	
	List<Employee1> findBySkill(String name);


}
