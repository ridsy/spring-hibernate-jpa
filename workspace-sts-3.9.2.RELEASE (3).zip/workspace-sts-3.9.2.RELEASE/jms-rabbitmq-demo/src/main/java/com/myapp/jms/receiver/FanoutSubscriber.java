package com.myapp.jms.receiver;

import java.io.IOException;

import com.myapp.jms.utils.ExchangeQueueUtils;
import com.myapp.jms.utils.RabbitMQConnection;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.client.AMQP.BasicProperties;

public class FanoutSubscriber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Connection connection = RabbitMQConnection.getConnection();

	    	if(connection!=null) {
	    	         
	    	    	   try {
	    			Channel channel =connection.createChannel();
	    			Consumer consumer1 = new DefaultConsumer(channel) {
	    				
	    				@Override
	    				public void handleDelivery(String consumerTag, Envelope envelope, BasicProperties properties,
	    						byte[] body) throws IOException {
	    					// TODO Auto-generated method stub
	    					String message = new String(body,"UTF-8");
	    					System.out.println("ConsumerTag "+consumerTag);
	    					System.out.println("Envelope "+envelope.getExchange());
	    					System.out.println("Basic Properties "+
	    					properties.getContentType()+" "+properties.getMessageId());
	    					System.out.println("Message Received from Queue A "+message);
	    				
	    				}
	    				
	    			};
	    			channel.basicConsume(ExchangeQueueUtils.QUEUE_A,consumer1);
	    				
	    			} catch (IOException e) {
	    				// TODO Auto-generated catch block
	    				e.printStackTrace();
	    			} 


				

	}

	}

}
