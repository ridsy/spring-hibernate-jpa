package com.myapp.spring;



import java.util.Date;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.myapp.spring.config.AppConfig;
import com.myapp.spring.dao.OrderDAO;
import com.myapp.spring.hibernate.model.Customer;
import com.myapp.spring.hibernate.model.Order;


public class TestSpringJpaHibernate {

	public static void main(String[] args) {

		//STEP 1: START THE SPRING CONTAINER
		
		AbstractApplicationContext springContainer = new AnnotationConfigApplicationContext(AppConfig.class);
		
		//STEP 2:Request For a bean inside the Spring container
		OrderDAO orderDao = springContainer.getBean(OrderDAO.class);
		orderDao.findAll().forEach(System.out::println);
		
		Order order=new Order("D999",new Date(),new Date(),"NEW");
		Customer customer1 = new Customer("abcd", "efgh", "abc@efg.com");
		
		order.addCustomerToOrder(customer1);
		
		orderDao.save(order);
		
		
		//STEP 3:Close The Container
		springContainer.close();
	}

}
