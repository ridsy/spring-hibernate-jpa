package com.myapp.spring.service;

import java.util.List;

import com.myapp.spring.hibernate.model.Order;

public interface OrderService {

	List<Order> findAll();
	
	void save(Order order);
	
	Order find(long id);
	
	void update(long id,Order order);
}
