package com.myapp.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

//@SpringBootApplication(scanBasePackages="com.myapp.spring")
//@EnableJpaRepositories(basePackages="com.myapp.spring.repository")
//@EntityScan(basePackages="com.myapp.spring.hibernate.model")

@SpringBootApplication
public class SpringJpaMvcBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaMvcBootApplication.class, args);
	}
}
