
package com.myapp.spring.hibernate.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="new_flights")
public class Flight {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="FLIGHT_ID")
	private long id;
	
	@Column(name="FLIGHT_NUMBER")
	private String flight_num;
	
	@Column(name="SOURCE_CITY")
    private String fromCity;
	
	@Column(name="DESTINATION_CITY")
	private String toCity;
	
	@Column(name="FARE")
	private int price;
	
	@Column(name="DURATION")
	private int duration;
	
	@Column(name="CARRIER")
	private String company;
	
	public Flight() {
		// TODO Auto-generated constructor stub
	}

	

	public Flight(String flight_num, String fromCity, String toCity, int price, int duration, String company) {
		super();
		this.flight_num = flight_num;
		this.fromCity = fromCity;
		this.toCity = toCity;
		this.price = price;
		this.duration = duration;
		this.company = company;
	}



	public long getId() {
		return id;
	}

	private void setId(long id) {
		this.id = id;
	}

	
	public String getFlight_num() {
		return flight_num;
	}



	public void setFlight_num(String flight_num) {
		this.flight_num = flight_num;
	}



	public String getFromCity() {
		return fromCity;
	}

	public void setFromCity(String fromCity) {
		this.fromCity = fromCity;
	}

	public String getToCity() {
		return toCity;
	}

	public void setToCity(String toCity) {
		this.toCity = toCity;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((flight_num == null) ? 0 : flight_num.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Flight))
			return false;
		Flight other = (Flight) obj;
		if (flight_num == null) {
			if (other.flight_num != null)
				return false;
		} else if (!flight_num.equals(other.flight_num))
			return false;
		if (id != other.id)
			return false;
		return true;
	}



	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Flight [id=");
		builder.append(id);
		builder.append(", flight_num=");
		builder.append(flight_num);
		builder.append(", fromCity=");
		builder.append(fromCity);
		builder.append(", toCity=");
		builder.append(toCity);
		builder.append(", price=");
		builder.append(price);
		builder.append(", duration=");
		builder.append(duration);
		builder.append(", company=");
		builder.append(company);
		builder.append("]");
		return builder.toString();
	}
	
	

}
