package com.myapp.spring.controller;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.myapp.spring.hibernate.model.Flight;
import com.myapp.spring.repository.FlightRepository;

@RestController
public class FlightController {
	
	@Autowired
	private FlightRepository flightservice;

	@RequestMapping(value="/flights/find",method=RequestMethod.GET)
     public ResponseEntity<List<Flight>> getAllFlights(@RequestParam("fromCity")String fromCity,@RequestParam("toCity")String toCity,@RequestParam("Type")String type){
		
		List<Flight> flights = flightservice.findByFromCityAndToCity(fromCity,toCity);
		if(type.equals("fare")) {
		Collections.sort(flights, (f1, f2) -> ((f1.getPrice()-f2.getPrice()))); 
		}
		
		if(type.equals("duration")) {
			Collections.sort(flights, (f1, f2) -> ((f1.getDuration()-f2.getDuration()))); 
		}
		
		if(type.equals("both")) {
			flights = flights.stream()
					.sorted((f1,f2)->{
						if(f1.getPrice()==f2.getPrice()) {
							return Integer.compare(f1.getDuration(),f2.getDuration());
						}
						else {
							return Integer.compare(f1.getPrice(),f2.getPrice());
						}
					})
					.collect(Collectors.toList());
		}
		return new ResponseEntity<List<Flight>>(flights,HttpStatus.OK);
	}
	
	@RequestMapping(value="/flights",method=RequestMethod.POST)
	public ResponseEntity<String> placeAnOrder(@RequestBody Flight flight){
		flightservice.save(flight);
		return new ResponseEntity<String>("Flight Saved",HttpStatus.CREATED);
	}
}
