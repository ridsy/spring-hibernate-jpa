package com.myapp.spring.events;

import java.util.Date;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class MyCustomEventPublisher implements ApplicationEventPublisherAware{
	
	protected ApplicationEventPublisher aep;

	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher aep) {
		// TODO Auto-generated method stub
		this.aep=aep;
	}
	
	@Scheduled(fixedRate=3000L)
	public void publishEvents() {
		
		final Date date = new Date();
		
		final MyCustomEvent event = new MyCustomEvent(this, date.toString());
		aep.publishEvent(event);
		
	}
	

}
