package com.myapp.spring.events;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class MyCustomEventSubscriber {
	
	@EventListener({MyCustomEvent.class})
	public void handleChangeEvents(final MyCustomEvent event) {
		System.out.println("Event Recieved "+event.getMessage());
	}

}
