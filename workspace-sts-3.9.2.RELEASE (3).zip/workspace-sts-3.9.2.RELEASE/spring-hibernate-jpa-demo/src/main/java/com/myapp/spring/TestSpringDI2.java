package com.myapp.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.myapp.spring.config.AppConfig;
import com.myapp.spring.di.GreetingBean;
import com.myapp.spring.di.MyBean;

public class TestSpringDI2 {

	public static void main(String[] args) {

		//STEP 1: START THE SPRING CONTAINER
		
		AbstractApplicationContext springContainer = new AnnotationConfigApplicationContext(AppConfig.class);
		
		//STEP 2:Request For a bean inside the Spring container
		
		MyBean myBean = springContainer.getBean(MyBean.class);
//		GreetingBean greetingBean = springContainer.getBean("greetingBeanImpl2",GreetingBean.class);
		

		MyBean myBean1 = springContainer.getBean(MyBean.class);
		
		System.out.println("*************** "+(myBean==myBean1));
		
		System.out.println(myBean.display());
		
		//STEP 3:Close The Container
		springContainer.close();
	}

}
