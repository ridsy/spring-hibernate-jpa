package com.myapp.spring;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.myapp.spring.config.AppConfig;


public class TestSpringPubSub {

	public static void main(String[] args) {

		//STEP 1: START THE SPRING CONTAINER
		
		AbstractApplicationContext springContainer = new AnnotationConfigApplicationContext(AppConfig.class);
		
		//STEP 2:Request For a bean inside the Spring container
		
		
		//STEP 3:Close The Container
		//springContainer.close();
	}

}
