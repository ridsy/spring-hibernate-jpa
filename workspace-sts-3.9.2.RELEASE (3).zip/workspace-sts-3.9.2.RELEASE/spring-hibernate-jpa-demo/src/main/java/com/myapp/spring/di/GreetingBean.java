package com.myapp.spring.di;

public interface GreetingBean {
	
	String greeting();

}
