package com.myapp.spring.di;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("instance2")  //Spring managed bean
public class GreetingBeanImpl2 implements GreetingBean {

	@Autowired  //It matches based on type-first
	private Date date;
	
	@Autowired
	private Calendar calendar;
	
	@Override
	public String greeting() {

		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		
		return (hour<12)?"Good Morning ":"Good Afternoon "+date;
	}

}
