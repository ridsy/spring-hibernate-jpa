package com.myapp.spring.events;

import org.springframework.context.ApplicationEvent;

public class MyCustomEvent extends ApplicationEvent{
	
	private String message;

	public MyCustomEvent(Object source,String message) {
		super(source);
		this.message=message;
		// TODO Auto-generated constructor stub
	}
	
	public String getMessage() {
		return message;
	}
	
	

}
