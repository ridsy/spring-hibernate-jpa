package com.myapp.spring;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.myapp.spring.config.AppConfig;
import com.myapp.spring.di.DataSourceBean;
import com.myapp.spring.di.GreetingBean;

public class TestSpringDI3 {

	public static void main(String[] args) {

		//STEP 1: START THE SPRING CONTAINER
		
		AbstractApplicationContext springContainer = new AnnotationConfigApplicationContext(AppConfig.class);
		
		//STEP 2:Request For a bean inside the Spring container
		
		DataSourceBean datasourceBean = springContainer.getBean(DataSourceBean.class);
//		GreetingBean greetingBean = springContainer.getBean("greetingBeanImpl2",GreetingBean.class);
		
		try(Connection connection=datasourceBean.getConnection()){
			
			String sql = "select * from my_orders";
			try(Statement statement = connection.createStatement()){
				
				ResultSet rs = statement.executeQuery(sql);
				while(rs.next()) {
					System.out.println(rs.getLong(1)+" "+rs.getString(2));
				}
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		//STEP 3:Close The Container
		springContainer.close();
	}

}
