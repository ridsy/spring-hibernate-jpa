package com.myapp.spring;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.myapp.spring.config.AppConfig;
import com.myapp.spring.config.AppConfig2;
import com.myapp.spring.di.DataSourceBean;
import com.myapp.spring.di.GreetingBean;

public class TestSpringJdbcTemplate {

	public static void main(String[] args) {

		//STEP 1: START THE SPRING CONTAINER
		
		AbstractApplicationContext springContainer = new AnnotationConfigApplicationContext(AppConfig.class,AppConfig2.class);
		
		//STEP 2:Request For a bean inside the Spring container
	
		FlightDAO dao = springContainer.getBean(FlightDAO.class);//loose coupling
		
		dao.findAll().forEach(System.out::println);
		
		//FlightDAO dao1 = springContainer.getBean(FlightDAOImpl.class);//tight coupling
		
		//STEP 3:Close The Container
		springContainer.close();
	}

}
