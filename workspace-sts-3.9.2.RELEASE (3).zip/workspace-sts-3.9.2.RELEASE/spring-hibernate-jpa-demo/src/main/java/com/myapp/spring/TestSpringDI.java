package com.myapp.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.myapp.spring.config.AppConfig;
import com.myapp.spring.di.GreetingBean;

public class TestSpringDI {

	public static void main(String[] args) {

		//STEP 1: START THE SPRING CONTAINER
		
		AbstractApplicationContext springContainer = new AnnotationConfigApplicationContext(AppConfig.class);
		
		//STEP 2:Request For a bean inside the Spring container
		
		GreetingBean greetingBean = springContainer.getBean("instance2",GreetingBean.class);
//		GreetingBean greetingBean = springContainer.getBean("greetingBeanImpl2",GreetingBean.class);
		
		System.out.println(greetingBean.greeting());
		
		//STEP 3:Close The Container
		springContainer.close();
	}

}
