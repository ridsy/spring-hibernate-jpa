package com.myapp.spring.di;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;



@Component
//@Scope("singleton")
//@Scope("prototype")
public class MyBeanImpl implements MyBean {

//	
	@Autowired
	@Qualifier("instance2")
     private GreetingBean greetingBean;
     
     @PostConstruct
     public void initialize() {
    	 System.out.println("Inside Init");
     }
	
//	
//	@Autowired
//	public MyBeanImpl(@Qualifier("instance2")GreetingBean greetingBean) {
//		this.greetingBean = greetingBean;
//	}



	@Override
	public String display() {
		// TODO Auto-generated method stub
		return greetingBean.greeting();
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("Inside destroy");
	}

}
