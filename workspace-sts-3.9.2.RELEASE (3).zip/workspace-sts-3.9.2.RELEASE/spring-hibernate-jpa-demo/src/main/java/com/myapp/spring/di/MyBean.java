package com.myapp.spring.di;

public interface MyBean {
	
	String display();
	
	

}
